def adjust_results4_isadog(results_dic, dogsfile):
    dognames_dic = {}

    with open(dogsfile, "r") as infile:
        for line in infile:
            dog_name = line.strip()
            if dog_name not in dognames_dic:
                dognames_dic[dog_name] = 1
            else:
                print("**Warning: Duplicate dognames", dog_name)

    for key, labels in results_dic.items():
        pet_label, classifier_label = labels[0], labels[1]
        
        pet_is_dog = 1 if pet_label in dognames_dic else 0
        classifier_is_dog = 1 if classifier_label in dognames_dic else 0
        
        labels.extend([pet_is_dog, classifier_is_dog])
