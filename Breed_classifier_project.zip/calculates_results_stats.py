def calculates_results_stats(results_dic):
    results_stats = {}
    results_stats['n_dogs_img'] = 0
    results_stats['n_match'] = 0
    results_stats['n_correct_dogs'] = 0
    results_stats['n_correct_notdogs'] = 0
    results_stats['n_correct_breed'] = 0

    for key in results_dic:
        if results_dic[key][2] == 1:
            results_stats['n_match'] += 1
        if results_dic[key][2] == 1 and results_dic[key][3] == 1:
            results_stats['n_correct_breed'] += 1
        if results_dic[key][3] == 1:
            results_stats['n_dogs_img'] += 1
            if results_dic[key][4] == 1:
                results_stats['n_correct_dogs'] += 1
        else:
            if results_dic[key][4] == 0:
                results_stats['n_correct_notdogs'] += 1

    results_stats['n_images'] = len(results_dic)
    results_stats['n_notdogs_img'] = results_stats['n_images'] - results_stats['n_dogs_img']
    results_stats['pct_match'] = (results_stats['n_match'] / results_stats['n_images']) * 100
    results_stats['pct_correct_dogs'] = (results_stats['n_correct_dogs'] / results_stats['n_dogs_img']) * 100
    results_stats['pct_correct_breed'] = (results_stats['n_correct_breed'] / results_stats['n_dogs_img']) * 100

    if results_stats['n_notdogs_img'] > 0:
        results_stats['pct_correct_notdogs'] = (results_stats['n_correct_notdogs'] / results_stats['n_notdogs_img']) * 100
    else:
        results_stats['pct_correct_notdogs'] = 0.0

    return results_stats
