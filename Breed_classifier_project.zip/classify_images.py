from classifier import classifier

def classify_images(images_dir, petlabel_dic, model):
    results_dic = {}

    for filename, pet_labels in petlabel_dic.items():
        pet_label = pet_labels[0]
        model_label = classifier(images_dir + filename, model).lower().strip()
        match = 0
        
        label_position = model_label.find(pet_label)
        if pet_label in model_label:
            if (label_position == 0 and len(pet_label) == len(model_label)) or \
               (label_position == 0 or model_label[label_position - 1] == " ") and \
               (label_position + len(pet_label) == len(model_label) or model_label[label_position + len(pet_label)] in (",", " ")):
                match = 1
        
        results_dic[filename] = [pet_label, model_label, match]
    
    return results_dic
