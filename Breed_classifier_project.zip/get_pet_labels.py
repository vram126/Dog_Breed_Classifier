from os import listdir

def get_pet_labels(image_dir):
    """
    Creates a dictionary of pet labels based upon the filenames of the image 
    files. This is used to check the accuracy of the image classifier model.
    Parameters:
     image_dir - The (full) path to the folder of images that are to be
                 classified by pretrained CNN models (string)
    Returns:
     petlabels_dic - Dictionary storing image filename (as key) and Pet Image
                     Labels (as value)  
    """
    # Creates list of files in directory
    in_files = listdir(image_dir)
    
    # Creates empty dictionary for the labels
    petlabels_dic = dict()
   
    # Processes through each file in the directory, extracting only the words
    # of the file that contain the pet image label
    for idx in range(0, len(in_files), 1):
       
        # Skips file if starts with . (like .DS_Store of Mac OSX) because it 
        # isn't an pet image file
        if in_files[idx][0] != ".":
           
            # Uses split to extract words of filename into list image_name 
            image_name = in_files[idx].split("_")
       
            # Creates temporary label variable to hold pet label name extracted 
            pet_label = ""
           
            # Processes each of the character strings(words) split by '_' in 
            # list image_name by processing each word - only adding to pet_label
            # if word is all letters - then process by putting blanks between 
            # these words and putting them in all lowercase letters
            for word in image_name:
               
                # Only add to pet_label if word is all letters add blank at end
                if word.isalpha():
                    pet_label += word.lower() + " "
                   
            # strips off trailing whitespace
            pet_label = pet_label.strip()
           
            # If filename doesn't already exist in dictionary add it and its
            # pet label list, otherwise print an error message because indicates 
            # duplicate files (filenames)
            if in_files[idx] not in petlabels_dic:
                petlabels_dic[in_files[idx]] = [pet_label]  # Add pet_label inside a list
            else:
                print("Warning: Duplicate files exist in directory", 
                      in_files[idx])
 
    # returns dictionary of labels
    return petlabels_dic
